using System;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Collections.Generic;

namespace MapExpander
{
    class MainForm : Form
    {
        private TextBox txtInput;
        private TextBox txtOutput;
        private NumericUpDown numOrigW;
        private NumericUpDown numOrigH;
        private NumericUpDown numNewW;
        private NumericUpDown numNewH;
        private NumericUpDown numTileIndex;
        private NumericUpDown numSubIndex;
        private NumericUpDown numLevel;
        private ComboBox cboTheater;
        private ComboBox cboTerrain;
        private Button btnBrowseInput;
        private Button btnBrowseOutput;
        private Button btnRun;
        private Button btnLang;
        private Label lblStatus;
        private bool isChinese = true;

        // 语言资源
        private Dictionary<string, string> zh = new Dictionary<string, string>() {
            { "title", "扩图补充 - 周边地形填充工具" },
            { "input", "输入地图:" },
            { "output", "输出地图:" },
            { "origSize", "原始大小:" },
            { "newSize", "扩图后大小:" },
            { "theater", "剧场类型:" },
            { "terrain", "填充地形:" },
            { "tileIndex", "TileIndex:" },
            { "subIndex", "SubIndex" },
            { "level", "Level" },
            { "export", "导出Tile文本" },
            { "import", "导入Tile文本" },
            { "run", "开始填充" },
            { "hint", "说明: FA2扩图后，周边空白格子自动填充指定地形" },
            { "langBtn", "EN" },
        };
        private Dictionary<string, string> en = new Dictionary<string, string>() {
            { "title", "Map Expander - Terrain Filler" },
            { "input", "Input Map:" },
            { "output", "Output Map:" },
            { "origSize", "Original Size:" },
            { "newSize", "Expanded Size:" },
            { "theater", "Theater:" },
            { "terrain", "Fill Terrain:" },
            { "tileIndex", "TileIndex:" },
            { "subIndex", "SubIndex" },
            { "level", "Level" },
            { "export", "Export Tiles" },
            { "import", "Import Tiles" },
            { "run", "Fill" },
            { "hint", "Note: Auto-fill surrounding empty tiles after FA2 expansion" },
            { "langBtn", "中" },
        };

        // 常用地形数据表
        // 格式: 剧场 -> 地形名 -> (TileIndex, Level)
        private Dictionary<string, Dictionary<string, KeyValuePair<int, int>>> terrainData =
            new Dictionary<string, Dictionary<string, KeyValuePair<int, int>>>()
        {
            { "温带 (TEMPERAT)", new Dictionary<string, KeyValuePair<int, int>>() {
                { "水面", new KeyValuePair<int, int>(314, 1) },
                { "草地", new KeyValuePair<int, int>(0, 0) },
                { "海滩沙地", new KeyValuePair<int, int>(786, 0) },
            }},
            { "雪地 (SNOW)", new Dictionary<string, KeyValuePair<int, int>>() {
                { "水面", new KeyValuePair<int, int>(314, 1) },
                { "雪地", new KeyValuePair<int, int>(0, 0) },
            }},
            { "城市 (URBAN)", new Dictionary<string, KeyValuePair<int, int>>() {
                { "水面", new KeyValuePair<int, int>(314, 1) },
                { "草地", new KeyValuePair<int, int>(0, 0) },
            }},
            { "沙漠 (DESERT)", new Dictionary<string, KeyValuePair<int, int>>() {
                { "水面", new KeyValuePair<int, int>(286, 1) },
                { "沙地", new KeyValuePair<int, int>(0, 0) },
            }},
            { "月球 (LUNAR)", new Dictionary<string, KeyValuePair<int, int>>() {
                { "月表深色", new KeyValuePair<int, int>(49, 0) },
                { "月表浅色", new KeyValuePair<int, int>(109, 0) },
            }},
        };

        public MainForm()
        {
            Text = "扩图补充 - 周边地形填充工具";
            Width = 540;
            Height = 460;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;

            // 语言切换按钮（右上角）
            btnLang = new Button();
            btnLang.Text = "EN";
            btnLang.Location = new Point(490, 10);
            btnLang.Size = new Size(40, 25);
            btnLang.Click += OnToggleLang;
            Controls.Add(btnLang);

            int y = 20;
            int labelW = 100;
            int inputW = 280;
            int rowH = 30;

            // 输入地图
            AddLabel("输入地图:", 20, y + 3, labelW, "input");
            txtInput = AddTextBox(120, y, inputW);
            btnBrowseInput = AddButton("浏览...", 410, y - 1, 80, 25, OnBrowseInput);
            y += rowH;

            // 输出地图
            AddLabel("输出地图:", 20, y + 3, labelW, "output");
            txtOutput = AddTextBox(120, y, inputW);
            btnBrowseOutput = AddButton("浏览...", 410, y - 1, 80, 25, OnBrowseOutput);
            y += rowH + 10;

            // 原始大小
            AddLabel("原始大小:", 20, y + 3, labelW, "origSize");
            numOrigW = AddNumeric(120, y, 60, 10, 1000, 136);
            AddLabel("x", 185, y + 3, 15);
            numOrigH = AddNumeric(200, y, 60, 10, 1000, 140);
            AddLabel("格", 265, y + 3, 30);
            y += rowH;

            // 扩图后大小
            AddLabel("扩图后大小:", 20, y + 3, labelW, "newSize");
            numNewW = AddNumeric(120, y, 60, 10, 2000, 300);
            AddLabel("x", 185, y + 3, 15);
            numNewH = AddNumeric(200, y, 60, 10, 2000, 200);
            AddLabel("格", 265, y + 3, 30);
            y += rowH + 10;

            // 剧场选择
            AddLabel("剧场类型:", 20, y + 3, labelW, "theater");
            cboTheater = new ComboBox();
            cboTheater.Location = new Point(120, y);
            cboTheater.Size = new Size(150, 20);
            cboTheater.DropDownStyle = ComboBoxStyle.DropDownList;
            foreach (string t in terrainData.Keys) cboTheater.Items.Add(t);
            cboTheater.SelectedIndex = 2; // 默认城市
            cboTheater.SelectedIndexChanged += OnTheaterChanged;
            Controls.Add(cboTheater);
            y += rowH;

            // 地形选择
            AddLabel("填充地形:", 20, y + 3, labelW, "terrain");
            cboTerrain = new ComboBox();
            cboTerrain.Location = new Point(120, y);
            cboTerrain.Size = new Size(150, 20);
            cboTerrain.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTerrain.SelectedIndexChanged += OnTerrainChanged;
            Controls.Add(cboTerrain);
            y += rowH;

            // 填充tile参数（自动填，也可手动改）
            AddLabel("TileIndex:", 20, y + 3, labelW, "tileIndex");
            numTileIndex = AddNumeric(120, y, 60, 0, 1000, 314);
            AddLabel("SubIndex", 190, y + 3, 55, "subIndex");
            numSubIndex = AddNumeric(245, y, 40, 0, 255, 0);
            AddLabel("Level", 300, y + 3, 40, "level");
            numLevel = AddNumeric(345, y, 40, 0, 10, 1);
            y += rowH + 20;

            // 导出/导入按钮
            Button btnExport = AddButton("导出Tile文本", 20, y, 140, 30, OnExport);
            btnExport.Tag = "export";
            Button btnImport = AddButton("导入Tile文本", 170, y, 140, 30, OnImport);
            btnImport.Tag = "import";
            y += 40;

            // 运行按钮
            btnRun = AddButton("开始填充", 150, y, 200, 35, OnRun);
            btnRun.Tag = "run";
            y += 45;

            // 状态
            lblStatus = new Label();
            lblStatus.Location = new Point(20, y);
            lblStatus.Size = new Size(460, 40);
            lblStatus.Text = "说明: FA2扩图后，周边空白格子自动填充指定地形";
            lblStatus.Tag = "hint";
            lblStatus.ForeColor = Color.Gray;
            Controls.Add(lblStatus);

            // 初始化联动
            OnTheaterChanged(null, null);
        }

        private Label AddLabel(string text, int x, int y, int w, string tag = null)
        {
            Label l = new Label();
            l.Text = text;
            l.Location = new Point(x, y);
            l.Size = new Size(w, 20);
            if (tag != null) l.Tag = tag;
            Controls.Add(l);
            return l;
        }

        private TextBox AddTextBox(int x, int y, int w)
        {
            TextBox t = new TextBox();
            t.Location = new Point(x, y);
            t.Size = new Size(w, 20);
            Controls.Add(t);
            return t;
        }

        private NumericUpDown AddNumeric(int x, int y, int w, int min, int max, int val)
        {
            NumericUpDown n = new NumericUpDown();
            n.Location = new Point(x, y);
            n.Size = new Size(w, 20);
            n.Minimum = min;
            n.Maximum = max;
            n.Value = val;
            Controls.Add(n);
            return n;
        }

        private Button AddButton(string text, int x, int y, int w, int h, EventHandler onClick)
        {
            Button b = new Button();
            b.Text = text;
            b.Location = new Point(x, y);
            b.Size = new Size(w, h);
            b.Click += onClick;
            Controls.Add(b);
            return b;
        }

        private void OnToggleLang(object sender, EventArgs e)
        {
            isChinese = !isChinese;
            var lang = isChinese ? zh : en;
            var langBtnText = isChinese ? "EN" : "中";
            btnLang.Text = langBtnText;
            Text = lang["title"];

            // 遍历所有控件更新文字
            ApplyLang(this, lang);
        }

        private void ApplyLang(Control parent, Dictionary<string, string> lang)
        {
            foreach (Control c in parent.Controls)
            {
                if (c.Tag is string && lang.ContainsKey((string)c.Tag))
                {
                    c.Text = lang[(string)c.Tag];
                }
                if (c.HasChildren) ApplyLang(c, lang);
            }
        }

        private void OnTheaterChanged(object sender, EventArgs e)
        {
            string theater = (string)cboTheater.SelectedItem;
            if (theater == null || !terrainData.ContainsKey(theater)) return;

            cboTerrain.Items.Clear();
            foreach (string t in terrainData[theater].Keys) cboTerrain.Items.Add(t);
            if (cboTerrain.Items.Count > 0) cboTerrain.SelectedIndex = 0;
        }

        private void OnTerrainChanged(object sender, EventArgs e)
        {
            string theater = (string)cboTheater.SelectedItem;
            string terrain = (string)cboTerrain.SelectedItem;
            if (theater == null || terrain == null) return;
            if (!terrainData.ContainsKey(theater)) return;
            if (!terrainData[theater].ContainsKey(terrain)) return;

            var kv = terrainData[theater][terrain];
            numTileIndex.Value = kv.Key;
            numLevel.Value = kv.Value;
        }

        private void OnBrowseInput(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "RA2/YR地图|*.yrm;*.map|所有文件|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtInput.Text = dlg.FileName;
                // 默认输出到同目录
                if (string.IsNullOrEmpty(txtOutput.Text))
                {
                    string dir = Path.GetDirectoryName(dlg.FileName);
                    string name = Path.GetFileNameWithoutExtension(dlg.FileName);
                    txtOutput.Text = Path.Combine(dir, name + "_filled.yrm");
                }

                // 自动读取地图的宽高
                try
                {
                    string libDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "lib");
                    Assembly asmLogic = Assembly.LoadFrom(Path.Combine(libDir, "MapTool.Logic.dll"));
                    Type mapFileType = asmLogic.GetType("MapTool.Logic.MapFile");
                    object mapFile = Activator.CreateInstance(mapFileType, new object[] { dlg.FileName });
                    mapFileType.GetMethod("Load").Invoke(mapFile, new object[] { dlg.FileName });
                    int w = (int)mapFileType.GetProperty("FullWidth").GetValue(mapFile, null);
                    int h = (int)mapFileType.GetProperty("FullHeight").GetValue(mapFile, null);
                    numNewW.Value = w;
                    numNewH.Value = h;
                    lblStatus.Text = "已读取地图大小: " + w + " x " + h;
                    lblStatus.ForeColor = Color.Gray;
                }
                catch
                {
                    lblStatus.Text = "警告: 无法自动读取地图大小，请手动填写";
                    lblStatus.ForeColor = Color.Orange;
                }
            }
        }

        private void OnBrowseOutput(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "RA2/YR地图|*.yrm|所有文件|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtOutput.Text = dlg.FileName;
            }
        }

        private void OnExport(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();
            if (!File.Exists(input))
            {
                MessageBox.Show("请先选择输入地图!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "文本文件|*.txt";
            dlg.FileName = Path.GetFileNameWithoutExtension(input) + "_tiles.txt";
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                string libDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "lib");
                Assembly asmLogic = Assembly.LoadFrom(Path.Combine(libDir, "MapTool.Logic.dll"));
                Type mapFileType = asmLogic.GetType("MapTool.Logic.MapFile");
                Type mapTileType = asmLogic.GetType("MapTool.Logic.MapTile");

                object mapFile = Activator.CreateInstance(mapFileType, new object[] { input });
                mapFileType.GetMethod("Load").Invoke(mapFile, new object[] { input });
                MethodInfo loadTileMethod = mapFileType.GetMethod("LoadTileData",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                loadTileMethod.Invoke(mapFile, null);
                MethodInfo getTilesMethod = mapFileType.GetMethod("GetMapTiles",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                Array tiles = (Array)getTilesMethod.Invoke(mapFile, null);

                using (StreamWriter sw = new StreamWriter(dlg.FileName))
                {
                    for (int i = 0; i < tiles.Length; i++)
                    {
                        object tile = tiles.GetValue(i);
                        short x = (short)mapTileType.GetProperty("X").GetValue(tile, null);
                        short y = (short)mapTileType.GetProperty("Y").GetValue(tile, null);
                        int tileIdx = (int)mapTileType.GetProperty("TileIndex").GetValue(tile, null);
                        byte subIdx = (byte)mapTileType.GetProperty("SubTileIndex").GetValue(tile, null);
                        byte level = (byte)mapTileType.GetProperty("Level").GetValue(tile, null);
                        sw.WriteLine(x + "," + y + "," + tileIdx + "," + subIdx + "," + level);
                    }
                }

                lblStatus.Text = "已导出 " + tiles.Length + " 个tile到: " + dlg.FileName;
                lblStatus.ForeColor = Color.Green;
            }
            catch (Exception ex)
            {
                MessageBox.Show("导出失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnImport(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();
            string output = txtOutput.Text.Trim();
            if (!File.Exists(input))
            {
                MessageBox.Show("请先选择输入地图!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "文本文件|*.txt";
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                string libDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "lib");
                Assembly asmLogic = Assembly.LoadFrom(Path.Combine(libDir, "MapTool.Logic.dll"));
                Type mapFileType = asmLogic.GetType("MapTool.Logic.MapFile");
                Type mapTileType = asmLogic.GetType("MapTool.Logic.MapTile");

                object mapFile = Activator.CreateInstance(mapFileType, new object[] { input });
                mapFileType.GetMethod("Load").Invoke(mapFile, new object[] { input });
                MethodInfo loadTileMethod = mapFileType.GetMethod("LoadTileData",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                loadTileMethod.Invoke(mapFile, null);
                MethodInfo getTilesMethod = mapFileType.GetMethod("GetMapTiles",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                Array tiles = (Array)getTilesMethod.Invoke(mapFile, null);

                // 读取文本文件
                var tileDict = new Dictionary<string, int[]>(); // key: x,y -> [tileIdx, subIdx, level]
                string[] lines = File.ReadAllLines(dlg.FileName);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length < 5) continue;
                    int x, y;
                    if (!int.TryParse(parts[0], out x)) continue;
                    if (!int.TryParse(parts[1], out y)) continue;
                    int tileIdx, subIdx, level;
                    if (!int.TryParse(parts[2], out tileIdx)) continue;
                    if (!int.TryParse(parts[3], out subIdx)) continue;
                    if (!int.TryParse(parts[4], out level)) continue;
                    tileDict[x + "," + y] = new int[] { tileIdx, subIdx, level };
                }

                // 修改tile
                int changed = 0;
                for (int i = 0; i < tiles.Length; i++)
                {
                    object tile = tiles.GetValue(i);
                    short x = (short)mapTileType.GetProperty("X").GetValue(tile, null);
                    short y = (short)mapTileType.GetProperty("Y").GetValue(tile, null);
                    string key = x + "," + y;
                    if (tileDict.ContainsKey(key))
                    {
                        var vals = tileDict[key];
                        mapTileType.GetProperty("TileIndex").SetValue(tile, vals[0], null);
                        mapTileType.GetProperty("SubTileIndex").SetValue(tile, (byte)vals[1], null);
                        mapTileType.GetProperty("Level").SetValue(tile, (byte)vals[2], null);
                        changed++;
                    }
                }

                // 保存
                MethodInfo saveTileMethod = mapFileType.GetMethod("SaveTileData",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                saveTileMethod.Invoke(mapFile, null);
                MethodInfo saveMethod = mapFileType.GetMethod("Save",
                    new Type[] { typeof(string), typeof(bool), typeof(bool) });
                saveMethod.Invoke(mapFile, new object[] { output, false, false });

                lblStatus.Text = "已导入 " + changed + " 个tile，输出: " + output;
                lblStatus.ForeColor = Color.Green;
            }
            catch (Exception ex)
            {
                MessageBox.Show("导入失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnRun(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();
            string output = txtOutput.Text.Trim();
            int origW = (int)numOrigW.Value;
            int origH = (int)numOrigH.Value;
            int newW = (int)numNewW.Value;
            int newH = (int)numNewH.Value;
            int tileIdx = (int)numTileIndex.Value;
            int subIdx = (int)numSubIndex.Value;
            int level = (int)numLevel.Value;

            if (!File.Exists(input))
            {
                MessageBox.Show("输入地图文件不存在!", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(output))
            {
                MessageBox.Show("请选择输出路径!", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            btnRun.Enabled = false;
            lblStatus.Text = "正在处理...";
            lblStatus.ForeColor = Color.Black;
            Application.DoEvents();

            try
            {
                // 加载MapTool DLL
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string libDir = Path.Combine(baseDir, "lib");

                Assembly asmLogic = Assembly.LoadFrom(Path.Combine(libDir, "MapTool.Logic.dll"));
                Assembly asmUtil = Assembly.LoadFrom(Path.Combine(libDir, "Starkku.Utilities.dll"));

                Type mapFileType = asmLogic.GetType("MapTool.Logic.MapFile");
                Type mapTileType = asmLogic.GetType("MapTool.Logic.MapTile");

                // 创建MapFile并加载
                object mapFile = Activator.CreateInstance(mapFileType, new object[] { input });
                MethodInfo loadMethod = mapFileType.GetMethod("Load");
                loadMethod.Invoke(mapFile, new object[] { input });

                // 加载tile数据
                MethodInfo loadTileMethod = mapFileType.GetMethod("LoadTileData",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                loadTileMethod.Invoke(mapFile, null);

                // 获取所有tile
                MethodInfo getTilesMethod = mapFileType.GetMethod("GetMapTiles",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                Array tiles = (Array)getTilesMethod.Invoke(mapFile, null);

                // 计算居中偏移
                int leftPad = (newW - origW) / 2;
                int topPad = (newH - origH) / 2;
                int origX0 = leftPad;
                int origX1 = leftPad + origW - 1;
                int origY0 = topPad;
                int origY1 = topPad + origH - 1;

                int changed = 0;

                // 遍历所有tile
                for (int i = 0; i < tiles.Length; i++)
                {
                    object tile = tiles.GetValue(i);
                    short xp = (short)mapTileType.GetProperty("X").GetValue(tile, null);
                    short yp = (short)mapTileType.GetProperty("Y").GetValue(tile, null);
                    int curTileIdx = (int)mapTileType.GetProperty("TileIndex").GetValue(tile, null);

                    // 反算视觉坐标
                    int x = (xp - yp + (newW - 1) + 1) / 2;
                    int y = (xp + yp - (newW - 1) - 1) / 2;

                    // 判断是否在周边填充区域
                    // 放宽一格，确保边缘全覆盖（反算坐标有精度误差）
                    bool isFillArea = false;

                    // 上边（放宽到origY0，包含边缘那一排）
                    if (y >= 0 && y <= origY0) isFillArea = true;
                    // 下边（从origY1开始，放宽一格）
                    if (y >= origY1 && y < newH) isFillArea = true;
                    // 左边（中间高度范围内，放宽到origX0）
                    if (x >= 0 && x <= origX0 && y >= origY0 && y <= origY1) isFillArea = true;
                    // 右边（从origX1开始，放宽一格）
                    if (x >= origX1 && x < newW && y >= origY0 && y <= origY1) isFillArea = true;

                    if (isFillArea && curTileIdx == 0)
                    {
                        mapTileType.GetProperty("TileIndex").SetValue(tile, tileIdx, null);
                        mapTileType.GetProperty("SubTileIndex").SetValue(tile, (byte)subIdx, null);
                        mapTileType.GetProperty("Level").SetValue(tile, (byte)level, null);
                        changed++;
                    }
                }

                // 保存tile数据
                MethodInfo saveTileMethod = mapFileType.GetMethod("SaveTileData",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                saveTileMethod.Invoke(mapFile, null);

                // 保存地图文件
                MethodInfo saveMethod = mapFileType.GetMethod("Save",
                    new Type[] { typeof(string), typeof(bool), typeof(bool) });
                saveMethod.Invoke(mapFile, new object[] { output, false, false });

                lblStatus.Text = string.Format("完成! 共填充 {0} 个格子", changed);
                lblStatus.ForeColor = Color.Green;
                MessageBox.Show(string.Format("填充完成!\n共修改 {0} 个格子\n输出: {1}", changed, output),
                    "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "出错: " + ex.Message;
                lblStatus.ForeColor = Color.Red;
                MessageBox.Show("处理失败:\n" + ex.Message + "\n\n" + ex.StackTrace,
                    "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnRun.Enabled = true;
            }
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new MainForm());
        }
    }
}
